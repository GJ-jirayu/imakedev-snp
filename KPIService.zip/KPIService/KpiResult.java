package com.imake.moogle.lbs.backoffice.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class KpiResult implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer year;
    private Integer periodNo;
    private String employeeCode;
    private String kpiCode;
    private BigDecimal actualData;
    private BigDecimal actualScore;
    private String approvedFlag;
    private Date createdDt;
    private Integer kpiOrder;
    private BigDecimal kpiWeight;
    private BigDecimal lookupBaselineValue;
    private BigDecimal performancePercentage;
    private String targetData;
    private BigDecimal targetScore;
    private Date updatedDt;
    private BigDecimal weightPercentage;
    private String empName;
    private String etlFlag;
    private String kpiName;
    private String periodDesc;

    public KpiResult() {
    }

    public Integer getYear() {
        return this.year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getPeriodNo() {
        return this.periodNo;
    }

    public void setPeriodNo(Integer periodNo) {
        this.periodNo = periodNo;
    }

    public String getEmployeeCode() {
        return this.employeeCode;
    }

    public void setEmployeeCode(String employeeCode) {
        this.employeeCode = employeeCode;
    }

    public String getKpiCode() {
        return this.kpiCode;
    }

    public void setKpiCode(String kpiCode) {
        this.kpiCode = kpiCode;
    }

    public BigDecimal getActualData() {
        return this.actualData;
    }

    public void setActualData(BigDecimal actualData) {
        this.actualData = actualData;
    }

    public BigDecimal getActualScore() {
        return this.actualScore;
    }

    public void setActualScore(BigDecimal actualScore) {
        this.actualScore = actualScore;
    }

    public String getApprovedFlag() {
        return this.approvedFlag;
    }

    public void setApprovedFlag(String approvedFlag) {
        this.approvedFlag = approvedFlag;
    }

    public Date getCreatedDt() {
        return this.createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public Integer getKpiOrder() {
        return this.kpiOrder;
    }

    public void setKpiOrder(Integer kpiOrder) {
        this.kpiOrder = kpiOrder;
    }

    public BigDecimal getKpiWeight() {
        return this.kpiWeight;
    }

    public void setKpiWeight(BigDecimal kpiWeight) {
        this.kpiWeight = kpiWeight;
    }

    public BigDecimal getLookupBaselineValue() {
        return this.lookupBaselineValue;
    }

    public void setLookupBaselineValue(BigDecimal lookupBaselineValue) {
        this.lookupBaselineValue = lookupBaselineValue;
    }

    public BigDecimal getPerformancePercentage() {
        return this.performancePercentage;
    }

    public void setPerformancePercentage(BigDecimal performancePercentage) {
        this.performancePercentage = performancePercentage;
    }

    public String getTargetData() {
        return this.targetData;
    }

    public void setTargetData(String targetData) {
        this.targetData = targetData;
    }

    public BigDecimal getTargetScore() {
        return this.targetScore;
    }

    public void setTargetScore(BigDecimal targetScore) {
        this.targetScore = targetScore;
    }

    public Date getUpdatedDt() {
        return this.updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public BigDecimal getWeightPercentage() {
        return this.weightPercentage;
    }

    public void setWeightPercentage(BigDecimal weightPercentage) {
        this.weightPercentage = weightPercentage;
    }

    public String getEmpName() {
        return this.empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEtlFlag() {
        return this.etlFlag;
    }

    public void setEtlFlag(String etlFlag) {
        this.etlFlag = etlFlag;
    }

    public String getKpiName() {
        return this.kpiName;
    }

    public void setKpiName(String kpiName) {
        this.kpiName = kpiName;
    }

    public String getPeriodDesc() {
        return this.periodDesc;
    }

    public void setPeriodDesc(String periodDesc) {
        this.periodDesc = periodDesc;
    }
}

