package com.imake.moogle.lbs.backoffice.service;

import com.imake.moogle.lbs.backoffice.dto.EmployeeResult;
import com.imake.moogle.lbs.backoffice.dto.KPIMaster;
import com.imake.moogle.lbs.backoffice.dto.KpiResult;
import com.imake.moogle.lbs.backoffice.dto.Threshold;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public interface KPIService {
    List<Integer> listYear(String var1);

    List<KPIMaster> listMaster(String var1);

    List<EmployeeResult> searchEmployeeResult(String var1, String var2, String var3, String var4, String var5, String var6, String var7);

    int updateAdjustPercentage(String var1, BigDecimal[] var2, BigDecimal[] var3, Integer[] var4, Integer[] var5, String[] var6, String[] var7);

    List<KpiResult> searchKPI(String var1, Integer var2, Integer var3, String var4, String var5, String var6);

    int approveKPIResult(String var1, Integer[] var2, Integer[] var3, String[] var4, String[] var5, String var6);

    List<Threshold> searchThreshold(String var1);

    int saveThreshold(Threshold var1);

    int updateThreshold(Threshold var1);

    int deleteThreshold(Threshold var1);

    Threshold findThresholdById(Threshold var1, Serializable var2);

    int updateObject(Object var1);

    int deleteObject(Object var1);

    Object findById(Object var1, Serializable var2);

    int saveObject(Object var1);

    List searchObject(String var1);

    int executeQuery(String var1);

    List<String[]> assignKPI(String var1, String var2, Integer var3, Integer var4, String[] var5, String[] var6, String[] var7, String[] var8, String[] var9, String[] var10);

    int assignKPIUpdate(String var1, String var2, Integer var3, Integer var4, String[] var5, String[] var6, String[] var7, String[] var8, String[] var9, String[] var10);
}

