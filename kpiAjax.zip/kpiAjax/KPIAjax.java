package com.imake.moogle.lbs.ajax;

import com.imake.moogle.lbs.backoffice.dto.EmployeeResult;
import com.imake.moogle.lbs.backoffice.dto.KPIMaster;
import com.imake.moogle.lbs.backoffice.dto.KpiResult;
import com.imake.moogle.lbs.backoffice.dto.Threshold;
import com.imake.moogle.lbs.backoffice.service.KPIService;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import javax.servlet.ServletContext;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class KPIAjax {
    private final KPIService kpiService;

    public KPIAjax() {
        WebContext ctx = WebContextFactory.get();
        ServletContext servletContext = ctx.getServletContext();
        WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
        this.kpiService = (KPIService)wac.getBean("kpiService");
    }

    public String say() {
        return "";
    }

    public List<Integer> listYears(String query) {
        System.out.println("into listYear");
        return this.kpiService.listYear(query);
    }

    public List<KPIMaster> listMaster(String query) {
        return this.kpiService.listMaster(query);
    }

    public List<EmployeeResult> searchEmployeeResult(String SCHEMA, String year, String periodNo, String departmentCode, String positionCode, String employeeCode, String employeeName) {
        return this.kpiService.searchEmployeeResult(SCHEMA, year, periodNo, departmentCode, positionCode, employeeCode, employeeName);
    }

    public int updateAdjustPercentage(String SCHEMA, BigDecimal[] adjustPercentage, BigDecimal[] finalPercentage, Integer[] year, Integer[] periodNo, String[] employeeCode, String[] reason) {
        try {
            return this.kpiService.updateAdjustPercentage(SCHEMA, adjustPercentage, finalPercentage, year, periodNo, employeeCode, reason);
        } catch (Exception var9) {
            var9.printStackTrace();
            return 0;
        }
    }

    public List<KpiResult> searchKPI(String SCHEMA, Integer year, Integer periodNo, String employeeCode, String etl_flag, String approved_flag) {
        return this.kpiService.searchKPI(SCHEMA, year, periodNo, employeeCode, etl_flag, approved_flag);
    }

    public int approveKPIResult(String SCHEMA, Integer[] year, Integer[] periodNo, String[] employeeCode, String[] kpiCode, String approved_flag) {
        try {
            return this.kpiService.approveKPIResult(SCHEMA, year, periodNo, employeeCode, kpiCode, approved_flag);
        } catch (Exception var8) {
            var8.printStackTrace();
            return 0;
        }
    }

    public List<Threshold> searchThreshold(String thresholdName) {
        return this.kpiService.searchThreshold(thresholdName);
    }

    public int updateThreshold(Threshold threshold) {
        return this.kpiService.updateThreshold(threshold);
    }

    public int deleteThreshold(Threshold threshold) {
        return this.kpiService.deleteThreshold(threshold);
    }

    public Threshold findThresholdById(Threshold threshold) {
        return this.kpiService.findThresholdById(threshold, threshold.getThresholdId());
    }

    public int saveThreshold(Threshold threshold) {
        return this.kpiService.saveThreshold(threshold);
    }

    public int updateObject(Object threshold) {
        return this.kpiService.updateObject(threshold);
    }

    public int deleteObject(Object threshold) {
        return this.kpiService.deleteObject(threshold);
    }

    public Object findById(Object threshold, Serializable id) {
        return this.kpiService.findById(threshold, id);
    }

    public int saveObject(Object threshold) {
        return this.kpiService.saveObject(threshold);
    }

    public List searchObject(String query) {
        return this.kpiService.searchObject(query);
    }

    public int executeQuery(String query) {
        return this.kpiService.executeQuery(query);
    }

    public List<String[]> assignKPI(String SCHEMA, String query, Integer year, Integer periodNo, String[] kpiCodes, String[] kpiOrders, String[] kpiWeight, String[] targetData, String[] targetScore, String[] approved_flag) {
        try {
            return this.kpiService.assignKPI(SCHEMA, query, year, periodNo, kpiCodes, kpiOrders, kpiWeight, targetData, targetScore, approved_flag);
        } catch (Exception var12) {
            var12.printStackTrace();
            return null;
        }
    }

    public int assignKPIUpdate(String SCHEMA, String query, Integer year, Integer periodNo, String[] kpiCodes, String[] kpiOrders, String[] kpiWeight, String[] targetData, String[] targetScore, String[] approved_flag) {
        try {
            return this.kpiService.assignKPIUpdate(SCHEMA, query, year, periodNo, kpiCodes, kpiOrders, kpiWeight, targetData, targetScore, approved_flag);
        } catch (Exception var12) {
            var12.printStackTrace();
            return 0;
        }
    }
}

