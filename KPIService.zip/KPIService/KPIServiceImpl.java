package com.imake.moogle.lbs.backoffice.service.impl;

import com.imake.moogle.lbs.backoffice.dto.EmployeeResult;
import com.imake.moogle.lbs.backoffice.dto.KPIMaster;
import com.imake.moogle.lbs.backoffice.dto.KpiResult;
import com.imake.moogle.lbs.backoffice.dto.Threshold;
import com.imake.moogle.lbs.backoffice.service.KPIService;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class KPIServiceImpl implements KPIService {
    private SessionFactory sessionAnnotationFactory;

    public KPIServiceImpl() {
    }

    public SessionFactory getSessionAnnotationFactory() {
        return this.sessionAnnotationFactory;
    }

    public void setSessionAnnotationFactory(SessionFactory sessionAnnotationFactory) {
        this.sessionAnnotationFactory = sessionAnnotationFactory;
    }

    @Transactional(
        readOnly = true
    )
    public List<Integer> listYear(String query) {
        List list = null;

        try {
            list = this.sessionAnnotationFactory.getCurrentSession().createSQLQuery(query).list();
        } catch (Exception var4) {
            var4.printStackTrace();
        }

        System.out.println("listYear =" + list);
        return list;
    }

    @Transactional(
        readOnly = true
    )
    public List<KPIMaster> listMaster(String query) {
        ArrayList master = null;

        try {
            List e = this.sessionAnnotationFactory.getCurrentSession().createSQLQuery(query).list();
            if(e != null && e.size() > 0) {
                int size = e.size();
                master = new ArrayList(size);
                String id = "";

                for(int i = 0; i < size; ++i) {
                    KPIMaster kpiMaster = new KPIMaster();
                    Object[] obj = (Object[])e.get(i);
                    if(obj[0] instanceof Integer) {
                        Integer idObj = (Integer)obj[0];
                        id = String.valueOf(idObj.intValue());
                    } else {
                        id = (String)obj[0];
                    }

                    kpiMaster.setId(id);
                    kpiMaster.setName((String)obj[1]);
                    master.add(kpiMaster);
                }
            }
        } catch (Exception var10) {
            var10.printStackTrace();
        }

        return master;
    }

    @Transactional(
        readOnly = true
    )
    public List<EmployeeResult> searchEmployeeResult(String SCHEMA, String year, String periodNo, String departmentCode, String positionCode, String employeeCode, String employeeName) {
        ArrayList employeeResult = null;
        StringBuffer sb = new StringBuffer(" select em_result.period_no,p.period_desc,em_result.employee_code, concat(em.employee_name,\' \',em.employee_surname) as emp_name ,em_result.weight_percentage, em_result.adjust_percentage,em_result.adjustment_reason ,em_result.final_percentage ,em_result.year  from " + SCHEMA + ".employee_result  em_result inner join " + " " + SCHEMA + ".employee em on em_result.employee_code=em.employee_code inner join " + SCHEMA + ".period p  on" + " (em_result.period_no=p.period_no and em_result.year =p.year) ");
        boolean haveWhere = false;
        if(!year.equalsIgnoreCase("all")) {
            if(haveWhere) {
                sb.append(" and em_result.year=" + year.trim());
            } else {
                sb.append(" where em_result.year=" + year.trim());
            }

            haveWhere = true;
        }

        if(!periodNo.equalsIgnoreCase("all")) {
            if(haveWhere) {
                sb.append(" and em_result.period_no=" + periodNo.trim());
            } else {
                sb.append(" where em_result.period_no=" + periodNo.trim());
            }

            haveWhere = true;
        }

        if(!employeeCode.equalsIgnoreCase("all") && employeeCode.trim().length() > 0) {
            if(haveWhere) {
                sb.append(" and em_result.employee_code=\'" + employeeCode + "\' ");
            } else {
                sb.append(" where em_result.employee_code=\'" + employeeCode + "\' ");
            }

            haveWhere = true;
        }

        if(employeeName != null && employeeName.trim().length() > 0) {
            if(haveWhere) {
                sb.append(" and  concat(em.employee_name,\' \',em.employee_surname)=\'" + employeeName + "\' ");
            } else {
                sb.append(" where concat(em.employee_name,\' \',em.employee_surname)=\'" + employeeName + "\' ");
            }

            haveWhere = true;
        }

        if(!departmentCode.equalsIgnoreCase("all") && departmentCode.trim().length() > 0) {
            if(haveWhere) {
                sb.append(" and em.department_code=\'" + departmentCode + "\' ");
            } else {
                sb.append(" where em.department_code=\'" + departmentCode + "\' ");
            }

            haveWhere = true;
        }

        if(!positionCode.equalsIgnoreCase("All")) {
            if(haveWhere) {
                sb.append(" and em.position_name=\'" + positionCode + "\' ");
            } else {
                sb.append(" where em.position_name=\'" + positionCode + "\' ");
            }

            haveWhere = true;
        }

        sb.append(" order by  em_result.period_no asc ");
        System.out.println("Query -->" + sb.toString());

        try {
            List e = this.sessionAnnotationFactory.getCurrentSession().createSQLQuery(sb.toString()).list();
            if(e != null && e.size() > 0) {
                int size = e.size();
                employeeResult = new ArrayList(size);

                for(int i = 0; i < size; ++i) {
                    EmployeeResult emp = new EmployeeResult();
                    Object[] obj = (Object[])e.get(i);
                    emp.setPeriodNo(obj[0] != null?(Integer)obj[0]:null);
                    emp.setPeriodDesc(obj[1] != null?(String)obj[1]:null);
                    emp.setEmployeeCode(obj[2] != null?(String)obj[2]:null);
                    emp.setEmpName(obj[3] != null?(String)obj[3]:null);
                    emp.setWeightPercentage(obj[4] != null?(BigDecimal)obj[4]:null);
                    emp.setAdjustPercentage(obj[5] != null?(BigDecimal)obj[5]:null);
                    emp.setAdjustmentReason(obj[6] != null?(String)obj[6]:null);
                    emp.setFinalPercentage(obj[7] != null?(BigDecimal)obj[7]:null);
                    emp.setYear(obj[8] != null?(Integer)obj[8]:null);
                    employeeResult.add(emp);
                }
            }
        } catch (Exception var16) {
            var16.printStackTrace();
        }

        return employeeResult;
    }

    @Transactional(
        propagation = Propagation.REQUIRES_NEW,
        rollbackFor = {RuntimeException.class}
    )
    public int updateAdjustPercentage(String SCHEMA, BigDecimal[] adjustPercentage, BigDecimal[] finalPercentage, Integer[] year, Integer[] periodNo, String[] employeeCode, String[] reason) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        int returnId = 0;

        try {
            StringBuffer e = new StringBuffer();
            if(adjustPercentage != null && adjustPercentage.length > 0) {
                int size = adjustPercentage.length;

                for(int i = 0; i < size; ++i) {
                    e.setLength(0);
                    e.append("update " + SCHEMA + ".employee_result set adjust_percentage=:adjust_percentage , final_percentage=:final_percentage " + "\t,adjustment_reason=:reason" + ",updated_dt=now()" + " where year=" + year[i] + " and period_no=" + periodNo[i] + "\tand employee_code=\'" + employeeCode[i] + "\'");
                    SQLQuery query = session.createSQLQuery(e.toString());
                    query.setParameter("reason", reason[i]);
                    query.setParameter("adjust_percentage", adjustPercentage[i]);
                    query.setParameter("final_percentage", finalPercentage[i]);
                    returnId = query.executeUpdate();
                }
            }
        } catch (Exception var17) {
            var17.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnId;
    }

    @Transactional(
        readOnly = true
    )
    public List<KpiResult> searchKPI(String SCHEMA, Integer year, Integer periodNo, String employeeCode, String etl_flag, String approved_flag) {
        ArrayList kpiResult = null;

        try {
            String e = "select result.year,result.period_no,p.period_desc,result.employee_code\t,concat(em.employee_name,\' \',em.employee_surname) as emp_name , result.kpi_code ,kpi.kpi_name   ,result.target_score,result.actual_score from " + SCHEMA + ".kpi_result result inner join " + SCHEMA + ".kpi kpi " + " on result.kpi_code=kpi.kpi_code inner join\t" + SCHEMA + ".employee em on result.employee_code=em.employee_code  inner join " + SCHEMA + ".period p  on" + " (result.period_no=p.period_no and result.year =p.year) where kpi.etl_flag=\'" + etl_flag.trim() + "\'" + " and result.approved_flag = \'" + approved_flag.trim() + "\' and result.year=" + year.intValue() + " and result.period_no=" + periodNo.intValue() + " and em.employee_code=\'" + employeeCode + "\' ";
            List result = this.sessionAnnotationFactory.getCurrentSession().createSQLQuery(e).list();
            if(result != null && result.size() > 0) {
                int size = result.size();
                kpiResult = new ArrayList(size);

                for(int i = 0; i < size; ++i) {
                    KpiResult kpi = new KpiResult();
                    Object[] obj = (Object[])result.get(i);
                    kpi.setYear(obj[0] != null?(Integer)obj[0]:null);
                    kpi.setPeriodNo(obj[1] != null?(Integer)obj[1]:null);
                    kpi.setPeriodDesc(obj[2] != null?(String)obj[2]:null);
                    kpi.setEmployeeCode(obj[3] != null?(String)obj[3]:null);
                    kpi.setEmpName(obj[4] != null?(String)obj[4]:null);
                    kpi.setKpiCode(obj[5] != null?(String)obj[5]:null);
                    kpi.setKpiName(obj[6] != null?(String)obj[6]:null);
                    kpi.setTargetScore(obj[7] != null?(BigDecimal)obj[7]:null);
                    kpi.setActualScore(obj[8] != null?(BigDecimal)obj[8]:null);
                    kpiResult.add(kpi);
                }
            }
        } catch (Exception var14) {
            var14.printStackTrace();
        }

        return kpiResult;
    }

    @Transactional(
        propagation = Propagation.REQUIRES_NEW,
        rollbackFor = {RuntimeException.class}
    )
    public int approveKPIResult(String SCHEMA, Integer[] year, Integer[] periodNo, String[] employeeCode, String[] kpiCode, String approved_flag) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        int returnId = 0;

        try {
            StringBuffer e = new StringBuffer();
            if(employeeCode != null && employeeCode.length > 0) {
                int size = employeeCode.length;

                for(int i = 0; i < size; ++i) {
                    e.setLength(0);
                    e.append("update " + SCHEMA + ".kpi_result set approved_flag=:approved_flag  " + ",updated_dt=now()" + " where year=" + year[i] + " and period_no=" + periodNo[i] + "\tand employee_code=\'" + employeeCode[i] + "\'" + "\tand kpi_code=\'" + kpiCode[i] + "\'");
                    SQLQuery query = session.createSQLQuery(e.toString());
                    query.setParameter("approved_flag", approved_flag);
                    returnId = query.executeUpdate();
                }
            }
        } catch (Exception var16) {
            var16.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnId;
    }

    public List<Threshold> searchThreshold(String thresholdName) {
        return null;
    }

    @Transactional(
        propagation = Propagation.REQUIRES_NEW,
        rollbackFor = {RuntimeException.class}
    )
    public int updateThreshold(Threshold threshold) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        byte returnId = 0;

        try {
            session.update(threshold);
            returnId = 1;
        } catch (Exception var8) {
            var8.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnId;
    }

    @Transactional(
        propagation = Propagation.REQUIRES_NEW,
        rollbackFor = {RuntimeException.class}
    )
    public int deleteThreshold(Threshold threshold) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        byte returnId = 0;

        try {
            session.delete(threshold);
            returnId = 1;
        } catch (Exception var8) {
            var8.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnId;
    }

    @Transactional(
        propagation = Propagation.REQUIRES_NEW,
        rollbackFor = {RuntimeException.class}
    )
    public int updateObject(Object threshold) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        byte returnId = 0;

        try {
            session.update(threshold);
            returnId = 1;
        } catch (Exception var8) {
            var8.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnId;
    }

    @Transactional(
        propagation = Propagation.REQUIRES_NEW,
        rollbackFor = {RuntimeException.class}
    )
    public int deleteObject(Object threshold) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        byte returnId = 0;

        try {
            session.delete(threshold);
            returnId = 1;
        } catch (Exception var8) {
            var8.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnId;
    }

    public Threshold findThresholdById(Threshold threshold, Serializable id) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        Threshold threshold_return = null;

        try {
            threshold_return = (Threshold)session.get(threshold.getClass(), id);
        } catch (Exception var9) {
            var9.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return threshold_return;
    }

    public Object findById(Object obj, Serializable id) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        Object obj_return = null;

        try {
            obj_return = session.get(obj.getClass(), id);
        } catch (Exception var9) {
            var9.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return obj_return;
    }

    @Transactional(
        propagation = Propagation.REQUIRES_NEW,
        rollbackFor = {RuntimeException.class}
    )
    public int saveThreshold(Threshold threshold) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        byte returnId = 0;

        try {
            Serializable e = session.save(threshold);
            System.err.println(e + "xxxxxxxxxxxxxxxxxxx");
            returnId = 1;
        } catch (Exception var8) {
            var8.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnId;
    }

    @Transactional(
        propagation = Propagation.REQUIRES_NEW,
        rollbackFor = {RuntimeException.class}
    )
    public int saveObject(Object threshold) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        byte returnId = 0;

        try {
            session.save(threshold);
            returnId = 1;
        } catch (Exception var8) {
            var8.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnId;
    }

    @Transactional(
        readOnly = true
    )
    public List searchObject(String query) {
        try {
            List e = this.sessionAnnotationFactory.getCurrentSession().createSQLQuery(query).list();
            if(e != null && e.size() > 0) {
                return e;
            }
        } catch (Exception var3) {
            var3.printStackTrace();
        }

        return null;
    }

    @Transactional(
        propagation = Propagation.REQUIRES_NEW,
        rollbackFor = {RuntimeException.class}
    )
    public int executeQuery(String str) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        int returnId = 0;

        try {
            SQLQuery e = session.createSQLQuery(str.toString());
            returnId = e.executeUpdate();
        } catch (Exception var8) {
            var8.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnId;
    }

    public List<String[]> assignKPI(String SCHEMA, String query, Integer year, Integer periodNo, String[] kpiCodes, String[] kpiOrders, String[] kpiWeight, String[] targetData, String[] targetScore, String[] approved_flag) {
        System.out.println(" into assignKPI");
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        boolean returnId = false;
        int returnIdAll = 0;
        ArrayList results = new ArrayList();
        HashMap employee_codes = new HashMap();
        HashMap kpi_codes = new HashMap();

        try {
            StringBuffer e = new StringBuffer();
            SQLQuery sqlQuery = session.createSQLQuery(query);
            List result = sqlQuery.list();
            int size = result.size();
            String[] ids = new String[size];

            int employee_code_str;
            for(employee_code_str = 0; employee_code_str < size; ++employee_code_str) {
                Object[] employee_codes_size = (Object[])result.get(employee_code_str);
                ids[employee_code_str] = (String)employee_codes_size[0];
            }

            String kpi_code_str;
            int var39;
            for(employee_code_str = 0; employee_code_str < ids.length; ++employee_code_str) {
                for(var39 = 0; var39 < kpiCodes.length; ++var39) {
                    e.setLength(0);
                    e.append(" select count(*) from " + SCHEMA + ".kpi_result  where year= " + year + " and period_no=" + periodNo + " and employee_code=\'" + ids[employee_code_str] + "\' and " + " kpi_code=\'" + kpiCodes[var39] + "\'");
                    sqlQuery = session.createSQLQuery(e.toString());
                    BigInteger index = (BigInteger)sqlQuery.uniqueResult();
                    e.setLength(0);
                    kpi_code_str = "0";
                    if(approved_flag[var39] != null && approved_flag[var39].length() > 0 && approved_flag[var39].equals("Y")) {
                        kpi_code_str = "Y";
                    }

                    int var37;
                    if(index.intValue() > 0) {
                        e.append("update " + SCHEMA + ".kpi_result set approved_flag=:approved_flag  " + ",updated_dt=now()" + " where year=" + year + " and period_no=" + periodNo + "\tand employee_code=\'" + ids[employee_code_str] + "\'" + "\tand kpi_code=\'" + kpiCodes[var39] + "\'");
                        sqlQuery = session.createSQLQuery(e.toString());
                        sqlQuery.setParameter("approved_flag", kpi_code_str);
                        var37 = sqlQuery.executeUpdate();
                        returnIdAll += var37;
                    } else {
                        e.append("insert into " + SCHEMA + ".kpi_result set approved_flag=:approved_flag ,kpi_order=" + kpiOrders[var39] + ",kpi_weight=" + kpiWeight[var39] + ",target_data=\'" + targetData[var39] + "\',target_score=" + targetScore[var39] + ", created_dt=now(),updated_dt=now()" + ",year=" + year + ",period_no=" + periodNo + ",employee_code=\'" + ids[employee_code_str] + "\',kpi_code=\'" + kpiCodes[var39] + "\'");
                        sqlQuery = session.createSQLQuery(e.toString());
                        sqlQuery.setParameter("approved_flag", kpi_code_str);
                        var37 = sqlQuery.executeUpdate();
                        returnIdAll += var37;
                        employee_codes.put(ids[employee_code_str], ids[employee_code_str]);
                        kpi_codes.put(kpiCodes[var39], kpiCodes[var39]);
                    }
                }
            }

            String var38 = "";
            var39 = employee_codes.size();
            int var40 = 0;

            for(Iterator var41 = employee_codes.keySet().iterator(); var41.hasNext(); ++var40) {
                String kpi_codes_size = (String)var41.next();
                if(var40 == var39 - 1) {
                    var38 = var38 + "\'" + kpi_codes_size + "\'";
                } else {
                    var38 = var38 + "\'" + kpi_codes_size + "\',";
                }
            }

            if(var39 > 0) {
                var38 = "(" + var38 + ")";
            }

            kpi_code_str = "";
            int var42 = kpi_codes.size();
            var40 = 0;

            for(Iterator result_kpi = kpi_codes.keySet().iterator(); result_kpi.hasNext(); ++var40) {
                String size_kpi = (String)result_kpi.next();
                if(var40 == var42 - 1) {
                    kpi_code_str = kpi_code_str + "\'" + size_kpi + "\'";
                } else {
                    kpi_code_str = kpi_code_str + "\'" + size_kpi + "\',";
                }
            }

            if(var42 > 0) {
                kpi_code_str = "(" + kpi_code_str + ")";
            }

            if(var39 > 0) {
                e.setLength(0);
                e.append("select result.year,result.period_no,p.period_desc,result.employee_code\t,concat(em.employee_name,\' \',em.employee_surname) as emp_name , result.kpi_code ,kpi.kpi_name   ,result.target_score,result.actual_score,cast(result.kpi_order as char),cast(result.kpi_weight as char),cast(result.target_data as char),cast(result.target_score as char) from " + SCHEMA + ".kpi_result result inner join " + SCHEMA + ".kpi kpi " + " on result.kpi_code=kpi.kpi_code inner join\t" + SCHEMA + ".employee em on result.employee_code=em.employee_code  inner join " + SCHEMA + ".period p  on" + " (result.period_no=p.period_no and result.year =p.year)  where result.year=" + year + " and result.period_no=" + periodNo + " and result.employee_code in " + var38 + " and result.kpi_code in " + kpi_code_str + " order by em.employee_code, result.kpi_order");
                sqlQuery = session.createSQLQuery(e.toString());
                List var43 = sqlQuery.list();
                int var44 = var43.size();

                for(int k = 0; k < var44; ++k) {
                    Object[] obj = (Object[])var43.get(k);
                    String[] kpi_result = new String[]{obj[3] != null?(String)obj[3]:"", obj[4] != null?(String)obj[4]:"", obj[9] != null?(String)obj[9]:"", obj[5] != null?(String)obj[5]:"", obj[6] != null?(String)obj[6]:"", obj[10] != null?(String)obj[10]:"", obj[11] != null?(String)obj[11]:"", obj[12] != null?(String)obj[12]:""};
                    results.add(kpi_result);
                }
            }
        } catch (Exception var35) {
            var35.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return results;
    }

    public int assignKPIUpdate(String SCHEMA, String query, Integer year, Integer periodNo, String[] kpiCodes, String[] kpiOrders, String[] kpiWeight, String[] targetData, String[] targetScore, String[] approved_flag) {
        Session session = this.sessionAnnotationFactory.getCurrentSession();
        boolean returnId = false;
        int returnIdAll = 0;
        new ArrayList();

        try {
            StringBuffer e = new StringBuffer();
            SQLQuery sqlQuery = session.createSQLQuery(query);
            List result = sqlQuery.list();
            int size = result.size();
            String[] ids = new String[size];

            int i;
            for(i = 0; i < size; ++i) {
                Object[] j = (Object[])result.get(i);
                ids[i] = (String)j[0];
            }

            for(i = 0; i < ids.length; ++i) {
                for(int var29 = 0; var29 < kpiCodes.length; ++var29) {
                    e.setLength(0);
                    e.append(" select count(*) from " + SCHEMA + ".kpi_result  where year= " + year + " and period_no=" + periodNo + " and employee_code=\'" + ids[i] + "\' and " + " kpi_code=\'" + kpiCodes[var29] + "\'");
                    sqlQuery = session.createSQLQuery(e.toString());
                    BigInteger count = (BigInteger)sqlQuery.uniqueResult();
                    e.setLength(0);
                    String approved_flag_update = "0";
                    if(approved_flag[var29] != null && approved_flag[var29].length() > 0 && approved_flag[var29].equals("Y")) {
                        approved_flag_update = "Y";
                    }

                    int var30;
                    if(count.intValue() > 0) {
                        e.append("update " + SCHEMA + ".kpi_result set approved_flag=:approved_flag  ,kpi_order=" + kpiOrders[var29] + ",kpi_weight=" + kpiWeight[var29] + ",target_data=\'" + targetData[var29] + "\',target_score=" + targetScore[var29] + ", updated_dt=now()" + " where year=" + year + " and period_no=" + periodNo + "\tand employee_code=\'" + ids[i] + "\'" + "\tand kpi_code=\'" + kpiCodes[var29] + "\'");
                        sqlQuery = session.createSQLQuery(e.toString());
                        sqlQuery.setParameter("approved_flag", approved_flag_update);
                        var30 = sqlQuery.executeUpdate();
                        returnIdAll += var30;
                    } else {
                        e.append("insert into " + SCHEMA + ".kpi_result set approved_flag=:approved_flag ,kpi_order=" + kpiOrders[var29] + ",kpi_weight=" + kpiWeight[var29] + ",target_data=\'" + targetData[var29] + "\',target_score=" + targetScore[var29] + ", created_dt=now(),updated_dt=now()" + ",year=" + year + ",period_no=" + periodNo + ",employee_code=\'" + ids[i] + "\',kpi_code=\'" + kpiCodes[var29] + "\'");
                        sqlQuery = session.createSQLQuery(e.toString());
                        sqlQuery.setParameter("approved_flag", approved_flag_update);
                        var30 = sqlQuery.executeUpdate();
                        returnIdAll += var30;
                    }
                }
            }
        } catch (Exception var27) {
            var27.printStackTrace();
        } finally {
            if(session != null) {
                session = null;
            }

        }

        return returnIdAll;
    }
}

